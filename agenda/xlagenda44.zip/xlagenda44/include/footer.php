<?php
/********************************************************************************
*	POUR PERSONNALISER XLAgenda AJOUTEZ VOTRE CODE HTML DANS CE FICHIER
*********************************************************************************/
?>
	<!-- AJOUTEZ VOTRE CODE HTML AU DESSUS DE CETTE LIGNE -->
	<div id="cadre_footer">
		<ul id="footer">
			<li style="text-align:left">
				<a href="http://validator.w3.org/check?uri=referer"><img border="0" src="img/valid-xhtml10.png" alt="Valid XHTML 1.0 Transitional" height="31" width="88" /></a>&nbsp;
				<a href="http://jigsaw.w3.org/css-validator/"><img src="img/vcss.gif" alt="Valid CSS!" width="88" height="31" border="0" /></a>
			</li>
			<li style="text-align:center;">
				<a href="#top"><?php echo $lang['common_link_haut'] ?></a>
			</li>
			<li style="text-align:right;">
				<!-- POUR CONTRIBUER A FAIRE CONNAITRE CE SCRIPT, MERCI DE CONSERVER LE LIEN VERS XLAgenda -->
				<?php echo $lang['common_powered_by'] ?> <a href="http://xavier.lequere.net/xlagenda" target="_blank">XLAgenda <?php echo get_version() ?></a>
			</li>
		</ul>
	</div>
</div>
</body>
</html>